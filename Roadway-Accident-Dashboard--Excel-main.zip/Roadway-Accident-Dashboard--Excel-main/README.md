# Roadway-Accident-Dashboard--Excel
Executed Academic project to create a Road Accident Dashboard using Roadway Accident Database. These dashboards and datasets are
designed to provide high-quality information to citizens, industry, data users, and policy makers. Using Charts like Bar, Pie,
Donut, Line, Slicers, hyperlink, pivot tables which enables visual overview of data.

Conclusion: 1. In Casulaties type, Slight Casualties are high in number 351436(84.1%).
            2. Casulaties by Car vehicle type is high i.e. 333485.
            3. Casulaties by Road Type and Casulaties by Road Surface is high for Single Carriageway i.e. 309.7K and Dry Road Surface i.e. 279.4K.
            4. Casulaties by location high in Urban, while by Day/Night high in Daylight.
            5. Casulaties in Current Year(i.e. for 2022) has Reduced compare to Previous Year(i.e. for 2021).

Zipped file uploaded link is here: https://drive.google.com/file/d/12SW--l8smHtveXeLMwk8rYP6YFHdbTbA/view?usp=drive_link            
